export const environment = {
  production: true,
  URL: 'http://192.168.1.2:3000'
};
